## 1 Aufbau von Modulen und Paketen

### 1.1 Was ist ein Modul?

Ein Modul ist eine einzelne Python-Datei (`.py`), die Funktionen, Klassen oder Variablen enthält. Module helfen, Code logisch zu gliedern und wiederverwendbar zu machen.

Beispiel für ein Modul `math_utils.py`:

```python
# math_utils.py

def add(a, b):
    return a + b

def multiply(a, b):
    return a * b
```

Dieses Modul kann in anderen Dateien importiert werden:

```python
import math_utils

print(math_utils.add(2, 3))       # Ausgabe: 5
print(math_utils.multiply(4, 5))  # Ausgabe: 20
```

### 1.2 Was ist ein Paket?

Ein Paket ist ein Verzeichnis, das mehrere Module enthält und eine `__init__.py`-Datei besitzt. Diese Datei kennzeichnet das Verzeichnis als Paket.

Beispielstruktur:

```
my_package/
├── __init__.py
├── math_utils.py
└── string_utils.py
```

Inhalt von `__init__.py` (kann leer sein oder Exporte definieren):

```python
from .math_utils import add, multiply
from .string_utils import capitalize
```

Verwendung des Pakets:

```python
import my_package

print(my_package.add(2, 2))
```

## 2 HTML-Dokumentation erstellen mit MkDocs

### 2.1 Was ist MkDocs?

MkDocs ist ein Werkzeug zur Erstellung von Webseiten für Projektdokumentation. Es nutzt Markdown-Dateien als Inhalt und erzeugt daraus eine statische HTML-Seite.

### 2.2 Installation

MkDocs wird mit `pip` installiert:

```bash
pip install mkdocs
```

Optional kann ein Theme wie `material` installiert werden:

```bash
pip install mkdocs-material
```

### 2.3 Projektstruktur

Erzeuge ein neues Dokumentationsprojekt:

```bash
mkdocs new my-docs
cd my-docs
```

Projektstruktur:

```
my-docs/
├── docs/
│   └── index.md
└── mkdocs.yml
```

### 2.4 Dokumentation schreiben

Markdown-Dateien kommen ins `docs/`-Verzeichnis. Beispiel `docs/index.md`:

```markdown
# Willkommen

Dies ist die Dokumentation zu meinem Projekt.
```

### 2.5 Lokaler Server zum Testen

Starte einen lokalen Server zum Testen der HTML-Seite:

```bash
mkdocs serve
```

Die Seite ist nun unter `http://127.0.0.1:8000/` erreichbar.

### 2.6 HTML-Seite erstellen

Zum Erzeugen der HTML-Seite verwende:

```bash
mkdocs build
```

Die fertige Seite befindet sich im Verzeichnis `site/`.

### 2.7 Deployment (optional)

MkDocs unterstützt einfache Veröffentlichung mit GitHub Pages:

```bash
mkdocs gh-deploy
```

Das setzt voraus, dass dein Projekt in einem Git-Repository liegt.
