## 1 Bedingungen

### 1.1 `if`, `elif` und `else`

```python
a = 1
b = 2

if a > b:
    print('a ist größer als b')
elif a < b:  # = elseif bzw. else if in anderen Sprachen
    print('a ist kleiner als b')
else:
    print('a ist gleich b')
```

Häufig kann man direkte Vergleiche weglassen:

```python
check = True
string = 'Text'

if check is True:
    print('Bedingung erfüllt.')

if len(string) != 0:
    print('String ist nicht leer.')

# Kürzer:
if check:
    print('Bedingung erfüllt.')

if string:
    print('String ist nicht leer.')
```

### 1.2 Shorthand

```python
a = 1
b = 2

if a < b: print('a ist kleiner als b')
```

### 1.3 Ternary operators (conditional expressions)

```python
a = 1
b = 2

kommentar = 'a ist größer als b' if a > b else 'a ist kleiner als b'
print(kommentar)  # a ist kleiner als b
```

### 1.4 ShortHand Ternary

**Beispiel 1:**

```python
print( True or 'Some' )  # True
```

**Beispiel 2:**

```python
print( False or 'Some' )  # Some
```

**Beispiel 3:**

```python
output = None
msg = output or 'Keine Daten'
print(msg)  # Keine Daten
```

## 2 `Switch`-`Case`-Äquivalent für Python-Version < 3.10

Vor Python-Version 3.10 gibt es keine `Switch`-`Case`-Anweisung, sie muss simuliert werden:

```python
def switcher(age):
    if age < 18:
        msg = 'Minderjährig'
    elif age < 67:
        msg = 'Volljährig'
    elif age in range(0, 150):
        msg = 'Rentner'
    else:
        msg = 'Fehler'

    return msg

print( witcher(50))  # Volljährig
```

## 3 `match`-`case`

Seit Python 3.10 gibt es die `match`-`case`-Anweisung:

```python
age = 50

match age:
    case _ if age < 18:
        msg = 'Minderjährig'
    case _ if age < 67:
        msg = 'Volljährig'
    case _ if age in range(0, 150):
        msg = 'Rentner'
    case _:  # = default:
        msg = 'Fehler'

print(msg)  # Volljährig
```

## 4 Schleifen

### 4.1 `for`

```python
L = [0, 1, 2, 3]
count = len(L)

# von 0 bis count-1
for i in range(count):
    print(L[i], end=', ' if i < count-1 else '\n')  # 0, 1, 2, 3

# von 1 bis count-1
for i in range(1, count):
    print(L[i], end=', ' if i < count-1 else '\n')  # 1, 2, 3

# von 0 bis count-1 mit Schrittweite 2
for i in range(0, count, 2):
    print(L[i], end=', ' if i < count-2 else '\n')  # 0, 2

# von count-1 bis 0 (rückwärts)
for i in range(count-1, -1, -1):
    print(L[i], end=', ' if i != 0 else '\n')       # 3, 2, 1, 0
```

```python
D = {'A': 1, 'B': 3, 'C': 7}

for key in D:
    print(key, end=' ')  # A, B, C

print('')

for key, value in D.items():
    print(f'{key}={value}', end=' ')  # A=1 B=3 C=7
```

**Mit Zählervariable:**

```python
lst = ['A', 'B', 'C']

for i in range(len(lst)):
    print(lst[i])

# Kürzer:
for value in lst:
    print(value)

# Wird der Index benötigt:
for i, value in enumerate(lst):
    print(f'{i}: {value}')
```

**Bildung eines Iterators mittels `zip()`**:

```python
a = [1, 2, 3]
b = [4, 5, 6]

for i in range(len(a)):
    print(f'{a[i]} und {b[i]}')

# Besser:
for av, bv in zip(a, b):
    print(f'{av} und {bv}')

# Mit Index:
for i, (av, bv) in enumerate(zip(a, b)):
    print(f'{i}: {av} und {bv}')
```


### 4.2 `while`

```python
i = 0
m = 3

while i <= m:
    print(i)
    i += 1
```

```python
i = 0
m = 3
run = True

while run:
    print(i)
    if i == m: run = False
    i += 1
```

```python
i = 0
m = 3

while True:
    print(i)
    if i == m: break
    i += 1
```


