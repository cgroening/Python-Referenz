## 1 Ausgabe mit print()

### 1.1 Mit und ohne Zeilenumbruch

```python
x = 1
y = 2

print(x)
print(y)

print(x, y, sep=', ', end=' ')  # Kein Zeilenumbruch am Ende
print('(Meine Werte)')

print(x, end=', ')  # Komma statt Zeilenumbruch am Ende
print(y)

# Ausgabe:
# 1
# 2
# 1, 2 (Meine Werte)
# 1, 2
```

> [!info] Besonderheit bei der Verwendung von `print()` mit `end=''`
> Normalerweise geht die Ausgabe von `print()` in den Puffer. Wenn der `end`-Parameter verändert wird, wird der Puffer nicht mehr gespült, d. h. aus Effizienzgründen kann es sein, dass die Ausgabe nicht sofort erfolgt, wenn `print()` aufgerufen wird (z. B. in Schleifen). Abhilfe schafft die Verwendung des Parameters `flush`:
> 
> ```python
> print('Hallo', end='', flush=True)
> ```

### 1.2 Formatierung

```python
m = 123456789     # Masse in kg
g = 9.81          # Erdbeschleunigung
F = m * g / 1000  # Gewichtskraft in kN
print(f'F = {F} kN')       #F = 1211111.10009 kN
print(f'F = {round(F, 2)} kN')  #F = 1211111.1 kN
print(f'F = {F:.2f} kN')   #F = 1211111.10 kN
print(f'F = {F:.2e} kN')   #F = 1.21e+06 kN
print('F = %.2e kN'% (F))  #F = 1.21e+06 kN
```

## 2 Logging

```python
import logging

# Setup
level = logging.DEBUG
format = '[%(levelname)s] %(asctime)s - %(message)s'
logging.basicConfig(level=level, format=format)

# Beispiele
logging.info('Normale Info')
logging.debug('Debug-Info')
logging.error('Fehler...')
```

**Ausgabe:**

```
[INFO] 2025-02-27 23:22:36,954 - Normale Info
[DEBUG] 2025-02-27 23:22:36,955 - Debug-Info
[ERROR] 2025-02-27 23:22:36,956 - Fehler...
```

## 3 Tabellen

### 3.1 Mit "Bordmitteln" (ohne zus. Pakete)

**Beispiel 1:**

```python
s1 = 'a'
s2 = 'ab'
s3 = 'abc'
s4 = 'abcd'

print(f'{s1:>10}')  #    a
print(f'{s2:>10}')  #   cd
print(f'{s3:>10}')  #  bcd
print(f'{s4:>10}')  # abcd
```

**Beispiel 2:**

```python
for x in range(1, 11):
    print(f'{x:05} {x*x:3} {x*x*x:4}')
```

Ausgabe:

```
00001   1    1
00002   4    8
00003   9   27
00004  16   64
00005  25  125
00006  36  216
00007  49  343
00008  64  512
00009  81  729
00010 100 1000
```

### 3.2 `tabulate` und `prettytable`

```python
from tabulate import tabulate         # License: MIT
from prettytable import PrettyTable   # License: BSD (3 clause)

head = ['Name', 'Alter']              # Überschriften
data = [['Max', 33], ['Monika', 29]]  # Inhalt/Zeilen

# Paket "tabulate"
# https://github.com/astanin/python-tabulate
print(tabulate(tabular_data=data, headers=head, tablefmt='pretty',
               colalign=('left', 'right')))
# Alternative: tablefmt='fancy_outline'
print()

# Paket "prettytable"
# https://github.com/jazzband/prettytable
t = PrettyTable(head)
t.add_rows(data)
t.add_row(['Werner', 44])
t.align['Name'] = 'l'
t.align['Alter'] = 'r'
print(t)
print()
```

Ausgabe:

```
+--------+-------+
| Name   | Alter |
+--------+-------+
| Max    |    33 |
| Monika |    29 |
+--------+-------+

+--------+-------+
| Name   | Alter |
+--------+-------+
| Max    |    33 |
| Monika |    29 |
| Werner |    44 |
+--------+-------+
```

### 3.3 `texttable`

```python
from texttable import Texttable  # License: MIT
# Paket "texttable"
# https://github.com/foutaise/texttable/
t = Texttable()
t.set_cols_align(['l', 'c', 'r', 'l'])
t.set_cols_valign(['t', 'm', 'm', 'b'])

head = ['Name', 'Spitzname', 'Alter', 'Kommentar']
data = [['Herr\nMaximilian\nHansen', 'Max', 33, '2 Kinder'],
        ['Frau\nMonika\nPetersen', 'Moni', 29, 'kein\nKommentar']]

data.insert(0, head)
t.add_rows(data)
print(t.draw())
print()

t.set_deco(Texttable.HEADER)
print(t.draw())
```

Ausgabe:

```
+------------+-----------+-------+-----------+
|    Name    | Spitzname | Alter | Kommentar |
+============+===========+=======+===========+
| Herr       |           |       |           |
| Maximilian |    Max    |    33 |           |
| Hansen     |           |       | 2 Kinder  |
+------------+-----------+-------+-----------+
| Frau       |           |       |           |
| Monika     |   Moni    |    29 | kein      |
| Petersen   |           |       | Kommentar |
+------------+-----------+-------+-----------+

   Name      Spitzname   Alter   Kommentar
==========================================
Herr
Maximilian      Max         33
Hansen                           2 Kinder
Frau
Monika         Moni         29   kein
Petersen                         Kommentar
```

## 4 Eingabe mit `input()`

Eine Benutzereingabe aus der Konsole kann wie folgt eingelesen werden:

```python
print('Gib etwas ein:')
s = input()
print(f'Du hast den folgenden Text eingegeben: {s}')
```

## 5 Inhalt einer Textdatei lesen

### 5.1 Einzelne Zeichen oder Zeilen lesen

```python
# Datei öffnen
with open('textdok.txt', 'r') as f:
    # Inhalt lesen
    print(f.read(5))     # Erste 5 zeichen der Datei
    print(f.readline())  # Erste Zeile, die noch nicht gelesen wurde
    print(f.readline())  # Nächste Zeile, usw.
```

> [!NOTE]
> **`with`-statement:**
> 
> `f.close()` um die Datei zu schließen kann aufgrund des `with`-statements (Kontextmanager-Statement) entfallen. Die Datei wird auch geschlossen, wenn es innerhalb des `with`-statements zu einem Fehler kommt. **Daher ist diese Variante immer zu bevorzugen, um Resourcenlecks, Dateisperren und Datenverlust zu vermeiden!** Siehe auch [[21 Kontentext-Manager]].
> 

### 5.2 Komplette Datei lesen

```python
# Datei öffnen
with open('textdok.txt', 'r') as f:
    # Inhalt lesen
    text = f.read()       # Als String
    text = f.readlines()  # Als Liste
```

Alternative Möglichkeit, um die Zeilen einer Textdatei in einer Liste zu speichern (der Zeilenumbruch `\n` am Ende der Strings entfällt hierbei):

```python
# Datei öffnen
with open('textdok.txt', 'r'):
	# Inhalt lesen
	text = []
	for line in f:
	    text.append(line.replace('\n', ''))

print(text)
```

## 6 CSV-Datei lesen

```python
import csv

lines = []
with open('tabelle.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=';', quotechar='|')
    for row in reader:
        lines.append(row)

print(lines)
```

**Alternative mit Pandas:**

```python
import pandas as pd

# Data frame erstellen
# header = None, wenn keine Überschriften vorhanden sind
df = pd.read_csv('beispieldateien/tabelle.csv', header=0, sep=";", decimal=",",
                 names=['x-Wert', 'y-Wert'])
print(df)
print()
print(df.iloc[6]['x-Wert'])
print(df.iloc[6][1])
```

## 7 Weitere Dateioperationen

```python
import os

os.rename(from, to)   # Umbennen
os.remove(path)       # Löschen
os.chmod(file, 0700)  # Dateiberechtigungen
os.stat(file)         # Dateiinformationen wie Größe, Datum, usw.
```

## 8 Pfade mit `os` und `pathlib.Path`

Es gibt es zwei gängige Möglichkeiten, mit Dateipfaden und dem Dateisystem zu arbeiten:

1. Das ältere `os`-Modul (gemeinsam mit `os.path`)
2. Das modernere `pathlib`-Modul

### 8.1 Übersicht

| Funktion                     | `os` / `os.path`                  | `pathlib.Path`                         |
|-----------------------------|-----------------------------------|----------------------------------------|
| Pfad erstellen              | `os.path.join()`                  | `Path() / Path.joinpath()`             |
| Existenz prüfen             | `os.path.exists()`                | `Path.exists()`                        |
| Datei/Verzeichnis prüfen    | `os.path.isfile()` / `.isdir()`   | `Path.is_file()` / `Path.is_dir()`     |
| Absoluter Pfad              | `os.path.abspath()`               | `Path.resolve()`                       |
| Datei lesen/schreiben       | `open(path)`                      | `Path.read_text()` / `Path.write_text()` |
| Verzeichnisinhalt auflisten| `os.listdir()`                    | `Path.iterdir()`                       |

### 8.2 Beispiele mit `os`

```python
import os

# Pfad zusammensetzen
pfad = os.path.join("verzeichnis", "datei.txt")

# Prüfen, ob Pfad existiert
if os.path.exists(pfad):
    print("Pfad existiert.")

# Absoluten Pfad bekommen
absolut = os.path.abspath(pfad)
```

### 8.3 Beispiele mit `pathlib.Path`

```python
from pathlib import Path

# Pfad zusammensetzen
pfad = Path("verzeichnis") / "datei.txt"

# Existenz prüfen
if pfad.exists():
    print("Pfad existiert.")

# Absoluten Pfad bekommen
absolut = pfad.resolve()
```

### 8.4 Vorteile von `pathlib.Path`

- Objektorientiert: `Path` ist eine Klasse mit Methoden, was zu lesbarerem Code führt.
- Plattformunabhängig: `/` funktioniert auf allen Systemen (intern wird automatisch das richtige Trennzeichen verwendet).
- Übersichtlicher: Viele Methoden wie `.read_text()` oder `.mkdir()` sind direkt verfügbar.
- Bessere Lesbarkeit durch Methodenkette statt Funktionsverschachtelung.

> [!INFO] Was sollte man verwenden?
> `pathlib` wurde mit Python 3.4 eingeführt und ist mittlerweile der empfohlene Standard für Pfadoperationen. Nur bei sehr alten Projekten oder bei Kompatibilität mit Python 2 sollte noch `os.path` verwendet werden.

### 8.5 Kombination mit anderen Modulen

`pathlib.Path` lässt sich gut mit anderen Modulen kombinieren, z. B.:

```python
import shutil
pfad = Path("backup") / "datei.txt"
shutil.copy(pfad, Path("ziel") / "kopie.txt")
```

### 8.6 Zusammenfassung

- Für neue Projekte: Immer pathlib.Path verwenden.
- Für alte Projekte oder einfache Kompatibilität: `os.path` kann noch genutzt werden.
- Beide Module bieten ähnliche Funktionalität, aber `pathlib` ist moderner, klarer und objektorientiert.
