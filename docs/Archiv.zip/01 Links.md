# Links

## python.org

- [The Python Tutorial](https://docs.python.org/3/tutorial/)
- [The Python Language Reference](http://docs.python.org/3/reference/)
- [The Python Standard Library](http://docs.python.org/3/library/)
- [PEP-8: Style Guide for Python Code](http://www.python.org/dev/peps/pep-0008/)

## Sonstiges

- [book.pythontips.com](https://book.pythontips.com/en/latest/index.html)
- [programiz.com/python-programming](https://www.programiz.com/python-programming)