Siehe auch [03 Datenstrukturen (Collections)](03%20Datenstrukturen%20(Collections).md), Abschnitt "Sets bzw. Mengen".

## 1 Vergleichsoperatoren

| Ausdruck | Bedeutung                       |
| -------- | ------------------------------- |
| `a == b` | `a` ist gleich `b`              |
| `a != b` | `a` ist ungleich `b`            |
| `a < b`  | `a` ist kleiner als `b`         |
| `a > b`  | `a` ist größer als `b`          |
| `a <= b` | `a` ist kleiner oder gleich `b` |
| `a >= b` | `a` ist größer oder gleich `b`  |

## 2 Arithmetische Operatoren

| Ausdruck | Bedeutung         |
| -------- | ------------------------------ |
| `a + b`  | `a` wird zu `b` addiert        |
| `a - b`  | `b` wird von `a` subtrahiert   |
| `a / b`  | `a` wird durch `b` geteilt     |
| `a // b` | Ganzzahldivision von `a` durch `b` |
| `a % b`  | Rest von `a` durch `b`         |
| `a * b`  | `a` wird mit `b` multipliziert |
| `a ** b` | `a` hoch `b` (Potenz)          |

## 3 Bitweise Operatoren

| Ausdruck | Bedeutung      |
| -------- | ------------------------- |
| `a & b`  | Bitweises AND             |
| `a \| b` | Bitweises OR              |
| `a ^ b`  | Bitweises XOR             |
| `~a`     | Bitweises NOT (Eins-Komplement) |
| `a << b` | Bitweise Linksverschiebung |
| `a >> b` | Bitweise Rechtsverschiebung |

## 4 Logische Operatoren
| Ausdruck | Bedeutung    |
| -------- | ----------------------- |
| `a and b` | Beide sind wahr (AND)   |
| `a or b`  | Einer ist wahr (OR)     |
| `not a`   | `a` ist falsch (NOT)    |

## 5 Zusammengesetzte Zuweisungsoperatoren

| Ausdruck | Bedeutung                        |
| -------- | ------------------------------------------- |
| `a += b` | Wert addieren und zuweisen (`a = a + b`)   |
| `a -= b` | Wert subtrahieren und zuweisen (`a = a - b`) |
| `a /= b` | Wert teilen und zuweisen (`a = a / b`)     |
| `a //= b` | Ganzzahldivision und zuweisen (`a = a // b`) |
| `a *= b` | Wert multiplizieren und zuweisen (`a = a * b`) |
| `a **= b` | Potenzieren und zuweisen (`a = a ** b`) |
| `a \|= b` | Bitweises ODER und zuweisen (`a = a \| b`) |
| `a &= b`  | Bitweises UND und zuweisen (`a = a & b`) |
| `a ^= b`  | Bitweises XOR und zuweisen (`a = a ^ b`) |
| `a <<= b` | Linksverschiebung und zuweisen (`a = a << b`) |
| `a >>= b` | Rechtsverschiebung und zuweisen (`a = a >> b`) |




